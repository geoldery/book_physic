/**************************** Always learning *******************************\
 
 File          : Name Shapes.cpp
 Project       : Implement concepts of book c++ programming
 Platform      : Cross Plataform
 Creation Date : 04/Jun/2014
 Author        : Gelson Gomes rodrigues
 
 Description: Draw simple forms geometrics with c++ and OpenGl
 
 ================================== HISTORY ==================================
 When      Who         What
 --------- ----------- -------------------------------------------------------
 
 \*****************************************************************************/

#include "Shapes.h"

#ifdef _WIN32
#include <gl/gl.h>
#elif __linux__
#include <GL/glut.h>
#elif __APPLE__
#include<OpenGL/gl.h>
#endif


/*************/
/* Constants */
/*************/


/**********/
/* Macros */
/**********/


/********************/
/* Type definitions */
/********************/


/********************/
/* Constant strings */
/********************/




/***************************/
/* Static  variables */
/***************************/




/*===========================================================================*\
 Function   : draw from class Shape
 
 Description: Draw 3 geomeric form, Line, Triangle and Square
 Input      : t:type - kind of geometric form
 Output     : nothing
 Return     : nothing
 \*===========================================================================*/
void Shape::draw(type t)
{

    glClearColor(0,0,0,0);
    glClear(GL_COLOR_BUFFER_BIT);
  
    switch(t)
    {
            case LINE:
              glColor3f(0.0f, 0.0f, 1.0f);
              glBegin(GL_LINES);
              {
                  glVertex3f(  0.0,  0.6, 0.0);
                  glVertex3f( -0.2, -0.3, 0.0);
              }
              glEnd();
            break;
            
            case TRIANGLE:
              glColor3f(0.5f, 0.5f, 1.0f);
            glBegin(GL_TRIANGLES);
            {
                glVertex3f(  0.0,  0.6, 0.0);
                glVertex3f( -0.2, -0.3, 0.0);
                glVertex3f(  0.2, -0.3 ,0.0);
            }
                glEnd();
            
            break;
            
            case SQUARE:
              glColor3f(0.3f, 0.2f, 0.6f);
              glBegin(GL_POLYGON);
              {
                  glVertex3f(   0.0+0.3,  0.6, 0.0);
                  glVertex3f( -0.6+0.3,  0.6, 0.0);
                  glVertex3f(  -0.6+0.3, -0.3, 0.0);
                  glVertex3f(   0.0+0.3, -0.3 ,0.0);              }
              glEnd();
            break;
    }
    glFlush();
}

