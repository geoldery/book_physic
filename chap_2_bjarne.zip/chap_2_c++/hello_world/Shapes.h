/**************************** Always learning *******************************\
 
 File          : Name Shapes.h
 Project       : Implement concepts of book c++ programming
 Platform      : Cross Plataform
 Creation Date : 04/Jun/2014
 Author        : Gelson Gomes rodrigues
 
 Description: Draw simple forms geometrics with c++ and OpenGl
 
 ================================== HISTORY ==================================
 When      Who         What
 --------- ----------- -------------------------------------------------------
 
 \*****************************************************************************/


#ifndef __hello_world__Shape__
#define __hello_world__Shape__

/* c++ standards includes*/
#include <iostream>

#ifdef _WIN32
#include <gl/gl.h>
#elif __linux__
 #include <GL/glut.h>
#elif __APPLE__
#include<OpenGL/gl.h>
#endif

#include<vector>

using namespace std;

struct _Point
{
    float x;
    float y;
};

enum type{LINE,TRIANGLE,SQUARE};

class Shape
{
    public:
    Shape(){};
    ~Shape(){};
    void draw(type t);
};
#endif /* defined(__hello_world__Shape__) */
