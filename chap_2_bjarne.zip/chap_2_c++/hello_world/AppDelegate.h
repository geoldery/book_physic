//
//  AppDelegate.h
//  hello_world
//
//  Created by Gelson gomes rodrigues on 5/30/14.
//  Copyright (c) 2014 gel_edu. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>
@property (weak) IBOutlet NSButton *line;
@property (weak) IBOutlet NSButton *triangle;
@property (weak) IBOutlet NSButton *square;

@property (assign) IBOutlet NSWindow *window;

@end
