//
//  AppDelegate.m
//  hello_world
//
//  Created by Gelson gomes rodrigues on 5/30/14.
//  Copyright (c) 2014 gel_edu. All rights reserved.
//

#import "AppDelegate.h"
#import<Cocoa/Cocoa.h>
#include"Shapes.h"

@implementation AppDelegate
Shape *shape = new Shape();

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
}

- (IBAction)square:(id)sender {
  
  shape->draw(SQUARE);
}
- (IBAction)triangle:(id)sender {
  shape->draw(TRIANGLE);
}

- (IBAction)line:(id)sender {
 shape->draw(LINE);
}


@end
