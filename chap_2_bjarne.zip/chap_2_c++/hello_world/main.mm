//
//  main.m
//  hello_world
//
//  Created by Gelson gomes rodrigues on 5/30/14.
//  Copyright (c) 2014 gel_edu. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
