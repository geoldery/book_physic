/**************************** Always learning *******************************\
 
  File          : MParser.cpp
  Project       : Chapter 2 book Math and physics for programmers
  Platform      : Cross Plataform
  Creation Date : 05/June/2014
  Author        : Gelson Gomes rodrigues
 
  Description: Implements a simple mathematical parser with 
  grammar below:

  Expression -> Expression + Term | Expression - Term | Term
  Term       -> Term * Factor     | Term / Factor     | Factor
  Factor     -> ( Expression )    | - ( Expression )  | number | - number
 
  Due to the left-recursive structure of this grammar, the parser reads
  the input from right to left.
 ================================== HISTORY ==================================
 When      Who         What
 --------- ----------- -------------------------------------------------------

 \*****************************************************************************/


/* Local includes */
#include "Math_parser.h"

/* c++ standards includes*/
#include<iostream>
#include<vector>
#include<string>

using namespace std;

/*************/
/* Constants */
/*************/


/**********/
/* Macros */
/**********/


/********************/
/* Type definitions */
/********************/


/********************/
/* Constant strings */
/********************/




/***************************/
/* Static  variables */
/***************************/


/*===========================================================================*\
 Function   : isNumber
 
 Description: Check if char is a number.
 Input      : c - Character with symbol input
 Output     : nothing
 Return     : true - is a number
              else - not number
 \*===========================================================================*/
static bool isNumber(char c)
{
    return ((c>= '0' && c<= '9' ));
}


/***************************************************************************************/
/* Implements methods from class MParser */
/***************************************************************************************/



/*===========================================================================*\
 Function   : scan_input
 
 Description: Scan input and create a list with tokens.
              If input was incomplet program will be finish
 Input      : inputstring - atribute class MParser
 Output     : list_symbols - vector with each token from inputstring
 Return     : nothing
 \*===========================================================================*/
void MParser::scan_input()
{
    // Token new_token;
    static int count_tokens = 0;
    if(count_tokens >= inputstring.size())
    {
        cout << " Program finish"<<endl;    }
    
    
    switch (inputstring[count_tokens])
    {
        case '(':
            count_tokens++;
            list_symbols.push_back(new Token{"(",PARENTHSES_OPEN});
            break;
            
        case ')':
            count_tokens++;
            list_symbols.push_back(new Token{")",PARENTHSES_CLOSE});
            break;
            
        case '*':
            count_tokens++;
            list_symbols.push_back( new Token{"*",MULTI});
            break;
            
        case '+':
            count_tokens++;
            list_symbols.push_back(new Token{"+",PLUS});
            break;
            
        case '-':
            count_tokens++;
            list_symbols.push_back( new Token{"-",MINUS});
            break;
            
        case '/':
            count_tokens++;
            list_symbols.push_back(new Token{"/",DIVIDE});
            break;
            
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
        {
            char c = inputstring[count_tokens++];
            string num_aux="";
            while(isNumber(c) || c=='.')
            {
                num_aux += c;
                c = inputstring[count_tokens++];
            }
            
            count_tokens--;
            
            list_symbols.push_back(new Token{num_aux,NUMBER});
        }
            break;
            
        default:
        {
            cout << " Invalid input"<<endl;
            exit(1);
        }
            break;
            
    };
}



/*===========================================================================*\
 Function   : next_token
 
 Description: Update token_now with last token from list_symbos and pop 
              this list
 Input      : nothing
 Output     : nothing
 Return     : nothing
 \*===========================================================================*/
void MParser::next_token()
{
    token_now = list_symbols.back();    list_symbols.pop_back();
}

/*===========================================================================*\
 Function   : expression
 
 Description:  parses and evaluates an expression starting at
               the current reading position and extending to the left
 Input      :  nothing
 Output     :  nothing
 Return     :  return value of expression
 \*===========================================================================*/
float MParser::expression()
{
    float term_value;
    
    term_value = term();                                   /* parse and evaluate Expression -> Term         */
    if (token_now->kind == PLUS)                           /* if followed by a '+' (to the left)...         */
    {
        next_token();                                      /* advance reading position to the left          */
        return expression() + term_value;                  /* Expression -> Expression + Term               */
    }
    if (token_now->kind == MINUS)                          /* if followed by a '-' (to the left)...         */
    {
        next_token();
        return expression() - term_value;                  /* Expression -> Expression - Term               */
    }
    return term_value;
}



/*===========================================================================*\
 Function   : term
 
 Description: Parses and evaluates a term starting at the current reading
              position (terminal_position)
 Input      : nothing
 Output     : nothing
 Return     : return value of term
 \*===========================================================================*/
float MParser::term()
{
    float factor_value;
    
    factor_value = factor();                                /* Term -> Factor                               */
    if (token_now->kind == MULTI)                           /* if followed by a '*'...                      */
    {
        next_token();
        return term() * factor_value;                       /* Term -> Term * Factor                        */
    }
    if (token_now->kind == DIVIDE)                          /* if followed by a '/'...                      */
    {
        if (factor_value == 0.0)                            /* check for division for zero...               */
        {
            printf("Division by zero\n");
            exit(1);
        }
        next_token();
        return term() / factor_value;                       /* ... Term -> Term / Factor                    */
    }
    return factor_value;
}



/*===========================================================================*\
 Function   : AlphaRoll
 
 Description: parses and evaluates a factor starting at the current reading
              position (terminal_position)
 Input      : nothing
 Output     : nothing
 Return     : float number
 \*===========================================================================*/
float MParser::factor()
{
    float number_value;
    
    if (token_now->kind == NUMBER)                       /* Factor -> <number>                                */
    {
        number_value =   atof(token_now->tok.c_str());
        
        next_token();
    }
    else if (token_now->kind == PARENTHSES_CLOSE)        /* Factor -> ( Expression )                           */
    {
        
        next_token();
        number_value = expression();                     /* Evaluate expression left of the closed bracket...  */
        if (token_now->kind == PARENTHSES_OPEN)          /* ... and check for an open bracket afterwards       */
        {
            
            next_token();
        }else
        {
            printf("Syntax error\n");                    /* open bracket is missing                            */
            exit(1);
        }
    }
    else                                                 /* no other terminals that 'N' and ')' are allowed    */
    {
        printf("Syntax error\n");
        exit(1);
    }
    // Factor -> - Factor. Note: if followed by another
    //factor, '-' is an operator, not a sign
    ///   if (terminal[terminal_position] == '-' &&
    //       (terminal[terminal_position - 1] != 'N' &&  /* symbol to the left of "-" is number?              */
    //       terminal[terminal_position - 1] != ')'))    /* symbol to the left of "-" is (Expression) ?       */
    // {
    //     terminal_position--;                          /* minus sign read */
    //     return -number_value;                         /* minus sign detected -> return negative value      */
    // }
    return number_value;                                 /* otherwise, return positive value                  */
}



/*===========================================================================*\
 Function   : parse
 
 Description: main function for calculate math expression
 Input      : val - string with math expression
 Output     : nothing
 Return     : float number - result from expression()
 \*===========================================================================*/
float MParser::parse(const string &val)
{
    list_symbols.push_back(new Token{"S",UNKOWN});
    // for(char c : inputstring)
    for(int i=1;i<inputstring.size();i++)
    {
        scan_input();
    }
    
    next_token();
    return expression();
 
}