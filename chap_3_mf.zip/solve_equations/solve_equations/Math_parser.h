/**************************** Always learning *******************************\
 
 File          : MParser.h
 Project       : Chapter 2 book Math and physics for programmers
 Platform      : Cross Plataform
 Creation Date : 05/June/2014
 Author        : Gelson Gomes rodrigues
 
 Description: Implements a simple mathematical parser
 
 Expression -> Expression + Term | Expression - Term | Term
 Term       -> Term * Factor     | Term / Factor     | Factor
 Factor     -> ( Expression )    | - ( Expression )  | number | - number
 
 Due to the left-recursive structure of this grammar, the parser reads
 the input from right to left.
 
 ================================== HISTORY ==================================
 When      Who         What
 --------- ----------- -------------------------------------------------------
 
 \*****************************************************************************/

#ifndef __solve_equations__Math_parser__
#define __solve_equations__Math_parser__


/* c++ standards includes*/
#include <iostream>
#include<vector>
using namespace std;

/* Local includes */


/*************/
/* Constants */
/*************/

enum Kind{UNKOWN=0,NUMBER,SYMBOL,VARIABLE,PLUS,MINUS,EQUAL,MULTI,DIVIDE,PARENTHSES_OPEN,PARENTHSES_CLOSE};

/**********/
/* Macros */
/**********/


/********************/
/* Type definitions */
/********************/

struct Token
{
    Token(){};
    Token(string s, Kind isT):tok{s},kind{isT}{};
    ~Token(){};
    string tok;
    Kind kind;
};

/********************/
/* Constant strings */
/********************/




/***************************/
/* Definition Class */
/***************************/


class MParser
{
    public:
        MParser(){};
        float parse(const string &val);
    private:
    
        /*    functions      */
        float expression(void);
        float term(void);
        float factor(void);
        void scan_input();
        void next_token();
        
    
        /*   atributes   */
        Token *token_now;
        string  inputstring;
        vector<Token*>  list_symbols;

    
};
#endif /* defined(__solve_equations__Math_parser__) */
