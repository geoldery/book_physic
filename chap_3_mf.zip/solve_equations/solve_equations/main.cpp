
#include<iostream>





int main(int arg, char *argv[])
{

   // inputstring = "((1+(3*3)+22)-1)";

    return 0;
}





